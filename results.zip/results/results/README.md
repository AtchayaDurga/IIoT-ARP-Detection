# IIoT-ARP Detection — Experimental Results

This folder contains selected, shareable experimental outputs for the IIoT ARP-spoofing detection project and the related UTFormer/DPD/DAS traffic-classification experiments.

## Folder map

- `edgeiiot_arp/` — Edge-IIoT ARP experiments: DPD ablations, DAS candidate/search results, efficiency benchmarks, feature/label audits, and plots.
- `edgeiiot_arp/dpd_das_run/` — metadata and result summary from the separate DPD+DAS run.
- `iscx_vpn2016/` — ISCX-VPN-2016 traffic-classification experiments, including result tables, figures, configuration, and the generated summary.
- `figures/` — proposed ARP UTFormer architecture image.

## Important: keep experimental scopes separate

`iscx_vpn2016/` contains VPN/non-VPN application-traffic classification results. These are **not** Edge-IIoT ARP-spoofing results. Do not combine their metrics in one comparison table.

The Edge-IIoT ARP metrics and the ISCX-VPN metrics use different datasets, labels, splits, and evaluation protocols. Always state the dataset and split next to reported metrics.

## Interpretation and reporting cautions

- Some ARP outputs show very high or perfect validation metrics. Treat these as preliminary until independently re-evaluated with a capture-wise or otherwise leakage-resistant split and sufficient attack/normal examples.
- `edgeiiot_arp/das/Final_Model_Comparison.csv` reports a small positive-class test support (18 positive examples in its confusion-matrix counts). Report the support and avoid broad generalization claims from this result alone.
- The DPD/DAS run metadata records a packet-level 70/10/20 split and explicitly distinguishes it from a flow-wise split. Describe the actual split used; do not call it flow-wise.
- The ISCX summary records a flow-segment split, three seeds for the main results, and deviations from the reference paper. Read `iscx_vpn2016/results_summary.md` before quoting its numbers.
- Efficiency measurements are environment-specific. Include hardware, software versions, batch size, and measurement method in the paper.

## Contents intentionally excluded

Raw PCAPs, packet-level arrays, processed full datasets, and model checkpoint binaries (`.pt`, `.pkl`, `.npy`, `.npz`) are not included. They can make a Git repository unnecessarily large and may require separate data/model hosting. Keep raw captures private unless you have verified the dataset license and redistribution permissions.

## Reproducibility

The corresponding implementation notebooks should live in the repository's `notebooks/` directory. Add environment dependencies and exact run instructions to the repository README before publication.
