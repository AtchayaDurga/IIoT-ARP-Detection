# UTFormer / ISCX-VPN-2016 — auto-generated results summary

Classes (6): Chat, Email, FileTransfer, Streaming, VoIP, P2P | packets: 31520 | capture files: 31 | archive scope: vpn
Protocol (main): flow-segment split (seg_len=100), seeds=[0, 1, 2], epochs=20, QUICK=False

## Differentiable architecture search (Tables 9-11, Figs 14-16)
Searched architecture (last iterate): {'Nh': 1, 'Nl': 1, 'd': 338, 'gamma': 0.422}; lowest-unified-loss iterate: {'Nh': 2, 'Nl': 1, 'd': 377, 'gamma': 0.44}; iterations run: 15; alpha=0.5, beta=1.5.
Paper-reported ISCX architecture: Nl=1, Nh=4, d=268, gamma=5%.

## Main results (Table 1)
| Model                         | Accuracy (%)   | Precision (%)   | Recall (%)   | F1 (%)       |
|:------------------------------|:---------------|:----------------|:-------------|:-------------|
| RF (stats + first 64 B)       | 98.80 ± 0.05   | 98.85 ± 0.06    | 98.89 ± 0.01 | 98.87 ± 0.04 |
| 1D-CNN                        | 72.36 ± 0.28   | 78.40 ± 2.29    | 71.69 ± 1.34 | 71.53 ± 0.63 |
| Transformer, no DPD (2L)      | 96.57 ± 0.26   | 96.63 ± 0.32    | 96.77 ± 0.31 | 96.69 ± 0.30 |
| UTFormer paper-cfg (1L, γ=5%) | 96.72 ± 0.14   | 96.67 ± 0.08    | 96.85 ± 0.10 | 96.76 ± 0.08 |
| UTFormer 2L γ=50%             | 96.70 ± 0.10   | 96.75 ± 0.12    | 96.94 ± 0.07 | 96.83 ± 0.05 |
| UTFormer 2L γ=20%             | 97.24 ± 0.14   | 97.29 ± 0.19    | 97.42 ± 0.15 | 97.35 ± 0.17 |
| UTFormer 2L γ=5%              | 97.00 ± 0.51   | 97.10 ± 0.31    | 97.22 ± 0.47 | 97.15 ± 0.38 |
| UTFormer-DAS (searched)       | 94.95 ± 0.58   | 95.14 ± 0.67    | 95.23 ± 0.50 | 95.15 ± 0.60 |

## Efficiency (Table 2)
                        Model  Params  Size (KB)  FLOPs/pkt (measured)  FLOPs (Eq.8 as printed)  FLOPs (Eq.8, no extra γ)  IPS (M/s)  GPU mem (MB)
      RF (stats + first 64 B)     NaN  26271.590                   NaN                      NaN                       NaN      0.031           NaN
                       1D-CNN 23622.0     92.273            12612480.0                      NaN                       NaN      0.060       177.881
     Transformer, no DPD (2L) 74694.0    291.773            17265920.0             33689600.000                33689600.0      0.035       335.553
UTFormer paper-cfg (1L, γ=5%) 59282.0    231.570             6028288.0             13782854.809                14107648.0      0.084       222.839
            UTFormer 2L γ=50% 74694.0    291.773            10925056.0             18180352.000                22596096.0      0.052       222.839
            UTFormer 2L γ=20% 74694.0    291.773             7685120.0             14431182.979                17062400.0      0.067       222.839
             UTFormer 2L γ=5% 74694.0    291.773             6215680.0             13808863.319                14596608.0      0.084       222.839
      UTFormer-DAS (searched) 68312.0    266.844             9164288.0              4913969.021                 6902272.0      0.100       136.288

## Scoring rules (Table 3)
Best rule per keep rate: γ=5% -> Head-mean CLS attention (paper) (95.66), γ=10% -> Random-k (95.37), γ=20% -> Learned gate (95.42), γ=50% -> Head-mean CLS attention (paper) (95.62)
Head-mean (paper) vs best, F1 pts: γ=5%: +0.00, γ=10%: +0.24, γ=20%: +0.40, γ=50%: +0.00
Treat differences below the seed std as ties.

## Leakage-aware evaluation (Table 4)
UTFormer F1: packet 96.79, segment 96.28, capture 67.94 -> packet-level inflation 0.51 pts over segment, 28.85 pts over held-out capture.

## Header reliance (Table 5)
Largest drop: "Mask first 96 B" (-45.62 F1 pts vs full input).

## Explainability
Top region per class (share of class-token attention): Chat: Early payload (40–167 B); Email: Early payload (40–167 B); FileTransfer: Early payload (40–167 B); Streaming: Early payload (40–167 B); VoIP: Padding (beyond packet); P2P: Early payload (40–167 B)
Faithfulness (deletion AUC, lower is better): Head-mean (paper) 0.170, Head-max 0.176, Received attn 0.447, Attn × ‖v‖ 0.171, Integrated Grad. 0.194, Random 0.468

## Reference (paper, ISCX-VPN 6 classes, different data/split): accuracy 94.35 %, F1 93.24 %, 156 KB, ~241.8 kFLOPs

## Deviations to disclose
- DAS: validation-loss gradient estimated with SPSA, normalised-step SGD (paper lr=0.005 did not move the parameters), search on a training subset, heads snapped to divisors of the embedding size.
- Flow-segment instead of whole-flow split; packet/segment sampling caps per capture and per class.
- Reduced epochs/seeds; offline throughput only (no DPDK 10 Gbps testbed).
- Eq. 8 of the paper multiplies the bracket by γ although C_Aγ and C_F already contain γ; both variants are reported.